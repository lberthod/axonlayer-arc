import BaseAgent from './baseAgent.js';
import { config } from '../config.js';
import taskEngine from '../core/taskEngine.js';
import paymentAdapter from '../core/paymentAdapter.js';
import agentRegistry from '../core/agentRegistry.js';
import pricingEngine from '../core/pricingEngine.js';
import providerStore from '../core/providerStore.js';
import { recordTaskMetric } from '../core/prometheus.js';

class OrchestratorAgent extends BaseAgent {
  constructor() {
    super('Orchestrator', config.wallets.orchestrator);
  }

  splitPayment(amount) {
    const fee = amount * config.treasury.feeRate;
    const agentAmount = amount - fee;
    return { fee, agentAmount };
  }

  async payAgentFromTreasury(agentWalletId, amount, reason, taskId) {
    if (config.treasury.balance < amount) {
      throw new Error(`Treasury insufficient: ${config.treasury.balance} < ${amount}`);
    }

    // Deduct from treasury
    config.treasury.balance = Number((config.treasury.balance - amount).toFixed(6));

    // Pay agent with agent_payment type
    await paymentAdapter.transfer(
      config.treasury.address,
      agentWalletId,
      amount,
      config.asset,
      reason,
      taskId,
      'agent_payment'
    );

    return {
      amount,
      from: config.treasury.address,
      to: agentWalletId
    };
  }

  async executeTask(inputText, taskType = 'summarize', options = {}) {
    const task = taskEngine.createTask(inputText, taskType, {
      requesterUid: options.requesterUid || null
    });
    const executionSteps = [];
    const budget = options.budget || config.pricing.clientPayment;
    let totalSpent = 0;

    const workerEntry = agentRegistry.selectWorker(taskType, options.selectionStrategy);
    const validatorEntry = agentRegistry.selectValidator(options.selectionStrategy);

    if (!workerEntry) {
      taskEngine.updateTaskStatus(task.id, 'failed');
      return {
        taskId: task.id,
        status: 'failed',
        error: `No worker available for task type "${taskType}"`,
        executionSteps,
        settlementType: paymentAdapter.mode
      };
    }

    const worker = workerEntry.agent;
    const validator = validatorEntry.agent;

    const pricing = pricingEngine.price({
      input: inputText,
      taskType,
      workerQuote: workerEntry.basePrice,
      validatorQuote: validatorEntry.basePrice
    });

    task.pricing = pricing;
    task.selectedWorker = workerEntry.id;
    task.selectedValidator = validatorEntry.id;
    task.budget = budget;

    try {
      executionSteps.push({
        step: 1,
        message: 'Task received',
        timestamp: new Date().toISOString()
      });

      // Fund mission from user wallet to treasury
      if (options.requesterUid) {
        await taskEngine.fundMission(options.requesterUid, budget, task.id);
        executionSteps.push({
          step: 2,
          message: `Mission funded: ${budget} USDC from user wallet to treasury`,
          timestamp: new Date().toISOString()
        });
      }

      // Pay worker from treasury with platform fee
      const { fee: workerFee, agentAmount: workerNetAmount } = this.splitPayment(pricing.workerPayment);
      await this.payAgentFromTreasury(
        worker.walletId,
        workerNetAmount,
        `Payment for ${workerEntry.id}`,
        task.id
      );
      totalSpent += pricing.workerPayment;

      executionSteps.push({
        step: 3,
        message: `Worker "${workerEntry.id}" paid ${workerNetAmount.toFixed(6)} USDC (fee: ${workerFee.toFixed(6)})`,
        timestamp: new Date().toISOString()
      });

      const workerResult = await worker.execute({
        text: inputText,
        taskType,
        targetLang: options.targetLang
      });

      executionSteps.push({
        step: 4,
        message: `Worker "${workerEntry.id}" executed task`,
        timestamp: new Date().toISOString()
      });

      // Pay validator from treasury with platform fee
      const { fee: validatorFee, agentAmount: validatorNetAmount } = this.splitPayment(pricing.validatorPayment);
      await this.payAgentFromTreasury(
        validator.walletId,
        validatorNetAmount,
        `Payment for ${validatorEntry.id}`,
        task.id
      );
      totalSpent += pricing.validatorPayment;

      executionSteps.push({
        step: 5,
        message: `Validator "${validatorEntry.id}" paid ${validatorNetAmount.toFixed(6)} USDC (fee: ${validatorFee.toFixed(6)})`,
        timestamp: new Date().toISOString()
      });

      const validationResult = await validator.execute({
        result: workerResult.result,
        originalText: inputText
      });

      executionSteps.push({
        step: 6,
        message: `Validator "${validatorEntry.id}" checked result`,
        timestamp: new Date().toISOString()
      });

      taskEngine.setTaskResult(task.id, workerResult.result);
      taskEngine.setTaskValidation(task.id, validationResult.validation);
      taskEngine.updateTaskStatus(
        task.id,
        validationResult.validation.valid ? 'completed' : 'failed'
      );

      agentRegistry.recordOutcome('worker', workerEntry.id, {
        success: validationResult.validation.valid,
        scoreFeedback: validationResult.validation.score
      });
      agentRegistry.recordOutcome('validator', validatorEntry.id, {
        success: true,
        scoreFeedback: validationResult.validation.score
      });

      // Marketplace providers: persist outcome + auto-slash on validation failure
      if (workerEntry.providerId) {
        await providerStore.recordOutcome(workerEntry.providerId, {
          success: validationResult.validation.valid,
          amount: pricing.workerPayment,
          score: validationResult.validation.score
        });
        if (!validationResult.validation.valid) {
          await providerStore.slash(
            workerEntry.providerId,
            config.marketplace.slashPenalty,
            `Task ${task.id} failed validation (score ${validationResult.validation.score})`
          );
        }
      }
      if (validatorEntry.providerId) {
        await providerStore.recordOutcome(validatorEntry.providerId, {
          success: true,
          amount: pricing.validatorPayment,
          score: 1
        });
      }

      // Refund unused budget
      let refundResult = { refunded: 0 };
      if (options.requesterUid) {
        refundResult = await taskEngine.refundUnusedBudget(options.requesterUid, task.id, budget, totalSpent);
        executionSteps.push({
          step: 7,
          message: refundResult.refunded > 0
            ? `Refunded ${refundResult.refunded.toFixed(6)} USDC to user wallet`
            : 'No refund needed (budget fully utilized)',
          timestamp: new Date().toISOString()
        });
      }

      const transactions = await paymentAdapter.getTransactions({ taskId: task.id });
      taskEngine.setTaskTransactions(task.id, transactions);

      executionSteps.push({
        step: 8,
        message: 'Task completed',
        timestamp: new Date().toISOString()
      });

      const updatedTask = taskEngine.getTask(task.id);

      recordTaskMetric({
        taskType,
        status: updatedTask.status,
        pricing
      });

      return {
        taskId: updatedTask.id,
        status: updatedTask.status,
        result: updatedTask.result,
        validation: updatedTask.validation,
        transactions,
        balances: await paymentAdapter.getAllBalances(),
        executionSteps,
        margin: pricing.orchestratorMargin,
        platformFee: workerFee + validatorFee,
        budget,
        spent: totalSpent,
        refunded: refundResult.refunded,
        pricing,
        selectedAgents: {
          worker: workerEntry.id,
          validator: validatorEntry.id
        },
        settlementType: paymentAdapter.mode
      };
    } catch (error) {
      taskEngine.updateTaskStatus(task.id, 'failed');

      agentRegistry.recordOutcome('worker', workerEntry.id, { success: false });
      recordTaskMetric({ taskType, status: 'failed' });

      // Refund on error
      if (options.requesterUid && totalSpent < budget) {
        try {
          await taskEngine.refundUnusedBudget(options.requesterUid, task.id, budget, totalSpent);
        } catch (refundError) {
          console.error('Refund failed:', refundError.message);
        }
      }

      executionSteps.push({
        step: 99,
        message: `Error: ${error.message}`,
        timestamp: new Date().toISOString()
      });

      return {
        taskId: task.id,
        status: 'failed',
        error: error.message,
        executionSteps,
        settlementType: paymentAdapter.mode
      };
    }
  }
}

export { OrchestratorAgent };
export default new OrchestratorAgent();
